import streamlit as st
import pandas as pd
import joblib

# =========================
# Page setup
# =========================
st.set_page_config(
    page_title="Bank Subscription Predictor",
    page_icon="💳",
    layout="wide"
)

# Simple CSS for nicer spacing and result cards
st.markdown("""
<style>
.big-title {font-size: 34px; font-weight: 800; margin-bottom: 0.2rem;}
.subtext {color: #666; margin-top: 0;}
.card {
  padding: 16px 18px;
  border-radius: 14px;
  border: 1px solid #eee;
  background: #fafafa;
}
.metric-card {
  padding: 14px 16px;
  border-radius: 14px;
  border: 1px solid #eee;
  background: white;
}
.small-note {color:#777; font-size: 13px;}
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def load_model():
    return joblib.load("model.pkl")

model = load_model()

def build_input_df(state: dict) -> pd.DataFrame:
    """Build a single-row DataFrame matching training column names."""
    return pd.DataFrame([{
        "age": state["age"],
        "job": state["job"],
        "marital": state["marital"],
        "education": state["education"],
        "default": state["default"],
        "balance": state["balance"],
        "housing": state["housing"],
        "loan": state["loan"],
        "contact": state["contact"],
        "day": state["day"],
        "month": state["month"],
        "duration": state["duration"],
        "campaign": state["campaign"],
        "pdays": state["pdays"],
        "previous": state["previous"],
        "poutcome": state["poutcome"],
    }])

def reset_form():
    for k in list(st.session_state.keys()):
        if k.startswith("f_"):
            del st.session_state[k]
    st.session_state["last_pred"] = None
    st.session_state["last_proba"] = None
    st.session_state["last_input"] = None

def apply_preset(name: str):
    """Quick presets to demonstrate the app (nice for demo + rubric)."""
    if name == "Likely YES":
        st.session_state["f_age"] = 35
        st.session_state["f_job"] = "management"
        st.session_state["f_marital"] = "married"
        st.session_state["f_education"] = "tertiary"
        st.session_state["f_default"] = "no"
        st.session_state["f_balance"] = 3500
        st.session_state["f_housing"] = "no"
        st.session_state["f_loan"] = "no"
        st.session_state["f_contact"] = "cellular"
        st.session_state["f_day"] = 15
        st.session_state["f_month"] = "may"
        st.session_state["f_duration"] = 900
        st.session_state["f_campaign"] = 1
        st.session_state["f_pdays"] = 120
        st.session_state["f_previous"] = 2
        st.session_state["f_poutcome"] = "success"
    elif name == "Likely NO":
        st.session_state["f_age"] = 45
        st.session_state["f_job"] = "blue-collar"
        st.session_state["f_marital"] = "married"
        st.session_state["f_education"] = "secondary"
        st.session_state["f_default"] = "yes"
        st.session_state["f_balance"] = 200
        st.session_state["f_housing"] = "yes"
        st.session_state["f_loan"] = "yes"
        st.session_state["f_contact"] = "unknown"
        st.session_state["f_day"] = 5
        st.session_state["f_month"] = "jun"
        st.session_state["f_duration"] = 60
        st.session_state["f_campaign"] = 5
        st.session_state["f_pdays"] = -1
        st.session_state["f_previous"] = 0
        st.session_state["f_poutcome"] = "unknown"


if "last_pred" not in st.session_state:
    st.session_state["last_pred"] = None
if "last_proba" not in st.session_state:
    st.session_state["last_proba"] = None
if "last_input" not in st.session_state:
    st.session_state["last_input"] = None


st.markdown('<div class="big-title">💳 Bank Subscription Predictor</div>', unsafe_allow_html=True)
st.markdown('<p class="subtext">Predict whether a customer is likely to subscribe to a term deposit based on customer and campaign details.</p>', unsafe_allow_html=True)

# Top quick actions (great for demo + “interactivity” marks)
colA, colB, colC, colD = st.columns([1.2, 1.2, 1.2, 2.4])
with colA:
    if st.button(" Load Preset: Likely YES"):
        apply_preset("Likely YES")
with colB:
    if st.button(" Load Preset: Likely NO"):
        apply_preset("Likely NO")
with colC:
    if st.button("Reset"):
        reset_form()
with colD:
    st.markdown('<span class="small-note">Tip: presets are useful for testing and for demo screenshots.</span>', unsafe_allow_html=True)

st.divider()


with st.sidebar:
    st.header("🧾 Customer Inputs")
    st.caption("Fill in details, then click **Predict**.")

    with st.form("input_form"):
        st.subheader("Customer Profile")
        age = st.slider("Age", 18, 95, st.session_state.get("f_age", 35), key="f_age",
                        help="Customer age in years.")
        job = st.selectbox("Job", [
            "admin.","blue-collar","entrepreneur","housemaid","management","retired",
            "self-employed","services","student","technician","unemployed","unknown"
        ], index=0 if "f_job" not in st.session_state else [
            "admin.","blue-collar","entrepreneur","housemaid","management","retired",
            "self-employed","services","student","technician","unemployed","unknown"
        ].index(st.session_state["f_job"]), key="f_job",
        help="Customer occupation category.")

        marital = st.selectbox("Marital status", ["married", "single", "divorced"],
                               index=0 if "f_marital" not in st.session_state else ["married","single","divorced"].index(st.session_state["f_marital"]),
                               key="f_marital", help="Customer marital status.")
        education = st.selectbox("Education level", ["primary", "secondary", "tertiary", "unknown"],
                                 index=0 if "f_education" not in st.session_state else ["primary","secondary","tertiary","unknown"].index(st.session_state["f_education"]),
                                 key="f_education", help="Highest education level.")
        default = st.selectbox("Has credit default?", ["no", "yes"],
                               index=0 if "f_default" not in st.session_state else ["no","yes"].index(st.session_state["f_default"]),
                               key="f_default", help="Whether customer has credit in default.")

        st.subheader("Financial Info")
        balance = st.number_input("Account balance", value=int(st.session_state.get("f_balance", 500)), step=100, key="f_balance",
                                  help="Balance in the customer's bank account (can be negative).")
        housing = st.selectbox("Has housing loan?", ["no", "yes"],
                               index=0 if "f_housing" not in st.session_state else ["no","yes"].index(st.session_state["f_housing"]),
                               key="f_housing")
        loan = st.selectbox("Has personal loan?", ["no", "yes"],
                            index=0 if "f_loan" not in st.session_state else ["no","yes"].index(st.session_state["f_loan"]),
                            key="f_loan")

        st.subheader("Campaign Contact Info")
        contact = st.selectbox("Contact type", ["cellular", "telephone", "unknown"],
                               index=0 if "f_contact" not in st.session_state else ["cellular","telephone","unknown"].index(st.session_state["f_contact"]),
                               key="f_contact")
        day = st.slider("Last contact day (1–31)", 1, 31, st.session_state.get("f_day", 15), key="f_day")
        month = st.selectbox("Last contact month", ["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"],
                             index=0 if "f_month" not in st.session_state else ["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"].index(st.session_state["f_month"]),
                             key="f_month")
        duration = st.number_input("Call duration (seconds)", value=int(st.session_state.get("f_duration", 180)), step=10, key="f_duration",
                                   help="Longer calls often mean higher interest (important feature).")
        campaign = st.slider("Contacts in this campaign", 1, 63, st.session_state.get("f_campaign", 2), key="f_campaign")
        pdays = st.number_input("Days since previous contact (-1 = never)", value=int(st.session_state.get("f_pdays", -1)), step=1, key="f_pdays")
        previous = st.slider("Contacts before this campaign", 0, 275, st.session_state.get("f_previous", 0), key="f_previous")
        poutcome = st.selectbox("Previous campaign outcome", ["unknown", "failure", "other", "success"],
                                index=0 if "f_poutcome" not in st.session_state else ["unknown","failure","other","success"].index(st.session_state["f_poutcome"]),
                                key="f_poutcome")

        submitted = st.form_submit_button("🔮 Predict")


tab1, tab2, tab3 = st.tabs(["📌 Prediction", "🧠 Explain Inputs", "ℹ️ Notes"])

# Build current input dict
current_state = {
    "age": st.session_state.get("f_age", 35),
    "job": st.session_state.get("f_job", "admin."),
    "marital": st.session_state.get("f_marital", "married"),
    "education": st.session_state.get("f_education", "primary"),
    "default": st.session_state.get("f_default", "no"),
    "balance": st.session_state.get("f_balance", 500),
    "housing": st.session_state.get("f_housing", "no"),
    "loan": st.session_state.get("f_loan", "no"),
    "contact": st.session_state.get("f_contact", "cellular"),
    "day": st.session_state.get("f_day", 15),
    "month": st.session_state.get("f_month", "may"),
    "duration": st.session_state.get("f_duration", 180),
    "campaign": st.session_state.get("f_campaign", 2),
    "pdays": st.session_state.get("f_pdays", -1),
    "previous": st.session_state.get("f_previous", 0),
    "poutcome": st.session_state.get("f_poutcome", "unknown"),
}

# Predict when form is submitted
if "submitted" in locals() and submitted:
    input_df = build_input_df(current_state)

    # Friendly validation warnings (UX marks)
    warnings = []
    if current_state["duration"] <= 0:
        warnings.append("Call duration is 0 or negative. Prediction may be less reliable.")
    if current_state["campaign"] >= 10:
        warnings.append("High campaign contacts can sometimes reduce success (customer may be annoyed).")
    if current_state["pdays"] < -1:
        warnings.append("pdays should normally be -1 or a positive number.")

    pred = int(model.predict(input_df)[0])
    proba = float(model.predict_proba(input_df)[0][1])

    st.session_state["last_pred"] = pred
    st.session_state["last_proba"] = proba
    st.session_state["last_input"] = input_df

    st.session_state["last_warnings"] = warnings

with tab1:
    left, right = st.columns([1.2, 1.0])

    with left:
        st.subheader("Result")
        if st.session_state["last_pred"] is None:
            st.info("Fill in the form on the left and click **Predict**.")
        else:
            proba = st.session_state["last_proba"]
            pred = st.session_state["last_pred"]

            # Show warnings if any
            for w in st.session_state.get("last_warnings", []):
                st.warning(w)

            # Result card
            if pred == 1:
                st.markdown('<div class="card"><b>Prediction:</b> YES  (Likely to subscribe)</div>', unsafe_allow_html=True)
            else:
                st.markdown('<div class="card"><b>Prediction:</b> NO  (Not likely to subscribe)</div>', unsafe_allow_html=True)

            st.write("**Probability of subscribing:**")
            st.progress(min(max(proba, 0.0), 1.0))
            st.write(f"{proba:.2f} (≈ {proba*100:.0f}%)")

            # Small hint for users
            st.caption("Tip: Try changing call duration and previous outcome to see how the probability changes.")

    with right:
        st.subheader("Your Inputs (Preview)")
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.json(current_state)
        st.markdown('</div>', unsafe_allow_html=True)


with tab2:
    st.subheader("What do these fields mean?")
    with st.expander("Customer Profile"):
        st.write("- **Age**: customer age.")
        st.write("- **Job / Marital / Education**: background info that can affect financial decisions.")
        st.write("- **Default**: whether customer has credit default (financial risk indicator).")

    with st.expander("Financial Info"):
        st.write("- **Balance**: amount of money in the account (higher balance can help subscription).")
        st.write("- **Housing / Loan**: existing loans may affect willingness to subscribe.")

    with st.expander("Campaign Info"):
        st.write("- **Contact type**: how the customer was contacted.")
        st.write("- **Day / Month**: when the customer was contacted.")
        st.write("- **Duration**: how long the call was (often very important).")
        st.write("- **Campaign**: number of contacts during this campaign.")
        st.write("- **Pdays**: days since last contact (-1 means never).")
        st.write("- **Previous / Poutcome**: what happened in the previous campaign.")


with tab3:
    st.subheader("Assumptions / Notes")
    st.write("- The model was trained on past marketing campaign data.")
    st.write("- The prediction is a guide, not a guaranteed outcome.")
    st.write("- The app works best when inputs are realistic.")
